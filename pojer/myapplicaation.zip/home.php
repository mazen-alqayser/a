<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الصفحة الرئيسية</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body class="container py-4">
    <h2>مرحبًا بك</h2>

    <form action="post_create.php" method="post" enctype="multipart/form-data" class="mb-4">
        <textarea name="content" class="form-control mb-2" placeholder="اكتب منشورك..."></textarea>
        <input type="file" name="image" class="form-control mb-2">
        <button type="submit" class="btn btn-primary">نشر</button>
    </form>

    <h4>المنشورات:</h4>
    <?php
    $posts = $conn->query("SELECT posts.*, users.name FROM posts JOIN users ON users.id = posts.user_id ORDER BY posts.created_at DESC");
    while ($row = $posts->fetch_assoc()) {
        echo '<div class="border p-2 mb-2">';
        echo "<b>{$row['name']}</b><br>{$row['content']}<br>";
        if ($row['image']) echo "<img src='uploads/{$row['image']}' width='200'><br>";
        echo "</div>";
    }
    ?>
</body>
</html>